import dotenv from 'dotenv';
import { connectDB } from '../config/db.js';
import { Movie } from '../models/Movie.js';
import { User } from '../models/User.js';

dotenv.config();

const movies = [
  { title: 'Inception', genre: ['Sci-Fi','Thriller'], releaseYear: 2010, posterUrl: 'https://image.tmdb.org/t/p/w500/qmDpIHrmpJINaRKAfWQfftjCdyi.jpg' },
  { title: 'The Dark Knight', genre: ['Action','Drama'], releaseYear: 2008, posterUrl: 'https://image.tmdb.org/t/p/w500/qJ2tW6WMUDux911r6m7haRef0WH.jpg' },
  { title: 'Interstellar', genre: ['Sci-Fi','Drama'], releaseYear: 2014, posterUrl: 'https://image.tmdb.org/t/p/w500/rAiYTfKGqDCRIIqo664sY9XZIvQ.jpg' }
];

const seed = async () => {
  await connectDB();
  await Movie.deleteMany({});
  await User.deleteMany({});
  await Movie.insertMany(movies);
  await User.create({ username: 'admin', email: 'admin@local', password: 'password', isAdmin: true });
  await User.create({ username: 'user', email: 'user@local', password: 'password' });
  console.log('Seeded DB');
  process.exit(0);
};

seed().catch(err => { console.error(err); process.exit(1); });
