import { User } from '../models/User.js';
import { Review } from '../models/Review.js';

export const getUser = async (req, res) => {
  const user = await User.findById(req.params.id).select('-password');
  if (!user) return res.status(404).json({ success: false, message: 'Not found' });
  const reviews = await Review.find({ user: user.id }).populate('movie', 'title posterUrl');
  res.json({ success: true, data: { user, reviews } });
};

export const updateUser = async (req, res) => {
  if (req.user.id !== req.params.id && !req.user.isAdmin) return res.status(403).json({ success: false, message: 'Forbidden' });
  const updated = await User.findByIdAndUpdate(req.params.id, req.body, { new: true }).select('-password');
  res.json({ success: true, data: updated });
};

export const getWatchlist = async (req, res) => {
  const user = await User.findById(req.params.id).populate('watchlist');
  if (!user) return res.status(404).json({ success: false, message: 'Not found' });
  res.json({ success: true, data: user.watchlist });
};

export const addToWatchlist = async (req, res) => {
  if (req.user.id !== req.params.id && !req.user.isAdmin) return res.status(403).json({ success: false, message: 'Forbidden' });
  const user = await User.findById(req.params.id);
  if (!user) return res.status(404).json({ success: false, message: 'Not found' });
  const { movieId } = req.body;
  if (!movieId) return res.status(400).json({ success: false, message: 'movieId required' });
  if (!user.watchlist.find(id => id.toString() === movieId)) user.watchlist.push(movieId);
  await user.save();
  res.status(201).json({ success: true });
};

export const removeFromWatchlist = async (req, res) => {
  if (req.user.id !== req.params.id && !req.user.isAdmin) return res.status(403).json({ success: false, message: 'Forbidden' });
  const user = await User.findById(req.params.id);
  if (!user) return res.status(404).json({ success: false, message: 'Not found' });
  user.watchlist = user.watchlist.filter(id => id.toString() !== req.params.movieId);
  await user.save();
  res.status(204).send();
};
