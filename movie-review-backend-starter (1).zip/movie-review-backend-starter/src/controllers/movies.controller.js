import { Movie } from '../models/Movie.js';
import { Review } from '../models/Review.js';
import { recalcAverageForMovie } from '../utils/calcAverage.js';

export const getMovies = async (req, res) => {
  const page = Number(req.query.page) || 1;
  const limit = Number(req.query.limit) || 12;
  const filter = {};
  if (req.query.genre) filter.genre = req.query.genre;
  if (req.query.year) filter.releaseYear = Number(req.query.year);
  if (req.query.ratingGte) filter.averageRating = { $gte: Number(req.query.ratingGte) };
  if (req.query.search) filter.title = { $regex: req.query.search, $options: 'i' };

  const [items, total] = await Promise.all([
    Movie.find(filter).sort({ createdAt: -1 }).skip((page - 1) * limit).limit(limit),
    Movie.countDocuments(filter)
  ]);
  res.json({ success: true, data: items, pagination: { page, limit, total } });
};

export const getMovieById = async (req, res) => {
  const movie = await Movie.findById(req.params.id);
  if (!movie) return res.status(404).json({ success: false, message: 'Not found' });
  const reviews = await Review.find({ movie: movie.id }).populate('user', 'username');
  res.json({ success: true, data: { movie, reviews } });
};

export const createMovie = async (req, res) => {
  const data = req.body;
  const doc = await Movie.create(data);
  res.status(201).json({ success: true, data: doc });
};

export const getReviewsForMovie = async (req, res) => {
  const reviews = await Review.find({ movie: req.params.id }).populate('user', 'username');
  res.json({ success: true, data: reviews });
};

export const addReview = async (req, res) => {
  const { rating, text } = req.body;
  if (!rating || rating < 1 || rating > 5) return res.status(400).json({ success: false, message: 'Invalid rating' });
  const review = await Review.create({ user: req.user.id, movie: req.params.id, rating, text });
  await recalcAverageForMovie(req.params.id);
  res.status(201).json({ success: true, data: review });
};
