import { User } from '../models/User.js';
import jwt from 'jsonwebtoken';

const sign = (id, isAdmin = false) => jwt.sign({ id, isAdmin }, process.env.JWT_SECRET, { expiresIn: '7d' });

export const register = async (req, res) => {
  const { username, email, password } = req.body;
  if (!username || !email || !password) return res.status(400).json({ success: false, message: 'Missing fields' });
  const exists = await User.findOne({ email });
  if (exists) return res.status(409).json({ success: false, message: 'Email already in use' });
  const user = await User.create({ username, email, password });
  res.status(201).json({ success: true, token: sign(user.id, user.isAdmin), user: { id: user.id, username: user.username, email: user.email } });
};

export const login = async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) return res.status(400).json({ success: false, message: 'Missing fields' });
  const user = await User.findOne({ email });
  if (!user) return res.status(401).json({ success: false, message: 'Invalid credentials' });
  const ok = await user.comparePassword(password);
  if (!ok) return res.status(401).json({ success: false, message: 'Invalid credentials' });
  res.json({ success: true, token: sign(user.id, user.isAdmin), user: { id: user.id, username: user.username, email: user.email } });
};
