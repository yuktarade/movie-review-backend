import { Review } from '../models/Review.js';
import { Movie } from '../models/Movie.js';
import mongoose from 'mongoose';

export const recalcAverageForMovie = async (movieId) => {
  const objId = mongoose.Types.ObjectId(movieId);
  const agg = await Review.aggregate([
    { $match: { movie: objId } },
    { $group: { _id: '$movie', avg: { $avg: '$rating' } } }
  ]);
  const avg = agg[0]?.avg ?? 0;
  await Movie.findByIdAndUpdate(movieId, { averageRating: Number(avg.toFixed(2)) });
};
