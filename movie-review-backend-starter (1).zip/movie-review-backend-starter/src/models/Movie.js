import mongoose from 'mongoose';

const movieSchema = new mongoose.Schema({
  title: { type: String, required: true, index: true },
  genre: [{ type: String, index: true }],
  releaseYear: { type: Number, index: true },
  director: String,
  cast: [String],
  synopsis: String,
  posterUrl: String,
  trailerUrl: String,
  averageRating: { type: Number, default: 0 }
}, { timestamps: true });

export const Movie = mongoose.model('Movie', movieSchema);
