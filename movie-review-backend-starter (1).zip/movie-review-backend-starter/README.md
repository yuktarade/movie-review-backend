# Movie Review Backend Starter

Minimal Node.js + Express + MongoDB starter for the MovieReview assignment.

## Quickstart
1. Copy `.env.example` -> `.env` and fill values (MONGO_URI, JWT_SECRET).
2. `npm install`
3. `npm run seed` (to insert demo movies and users)
4. `npm run dev` (development) or `npm start` (production)

## Seed users
- admin: admin@local / password  (isAdmin: true)
- user: user@local / password
